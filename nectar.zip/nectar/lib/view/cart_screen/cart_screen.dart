import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:nectar/utility/fontsize.dart';
import 'package:nectar/view/cart_screen/widget/bottomsheet_list.dart';
import 'package:nectar/widget/app_button.dart';

import '../../utility/app_color.dart';
import '../../utility/assets.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({super.key});

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  int _initial = 0;

  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      backgroundColor: AppColors.bgWhite,
      appBar: AppBar(
        automaticallyImplyLeading: false,
        elevation: 0,
        backgroundColor: AppColors.bgWhite,
        title: Text("My Cart",
          style: TextStyle(
              fontSize: titleFont,
              fontWeight: FontWeight.w600,
              color: Colors.black,
          ),
        ),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              shrinkWrap: true,
              itemCount: 10,
                itemBuilder: (context,index){
              return ListTile(

                shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
                contentPadding: EdgeInsets.all(20),
                leading: Image.asset(Assets.apple),
                title: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Red Apple",style: TextStyle(fontSize: titleFont,fontWeight: FontWeight.w600,color: Colors.black),),
                            Text("1kg, Price",style: TextStyle(fontSize: smallFont,fontWeight: FontWeight.w400,color: AppColors.textGrey),),
                          ],
                        ),
                        InkWell(
                            onTap:(){},
                            child: Icon(Icons.close,color: AppColors.textGrey,))
                      ],
                    ),
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            InkWell(
                              onTap: (){
                                setState(() {
                                  _initial--;
                                });
                              },
                              child: Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  border: Border.all(color: AppColors.textGrey),
                                  borderRadius: BorderRadius.circular(10),
                                  color: AppColors.bgWhite,
                                ),
                                child: Center(
                                  child: Icon(Icons.remove,color: Colors.black,),
                                ),
                              ),
                            ),
                            SizedBox(width: 10,),
                            Text("${_initial}",style: TextStyle(fontWeight: FontWeight.w600,fontSize: normalFont,color: Colors.black),),
                            SizedBox(width: 10,),
                            InkWell(
                              onTap: (){
                                setState(() {
                                  _initial++;
                                });
                              },
                              child: Container(
                                padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  border: Border.all(color: AppColors.textGrey),
                                  borderRadius: BorderRadius.circular(10),
                                  color: AppColors.bgWhite,
                                ),
                                child: Center(
                                  child: Icon(Icons.add,color: Colors.black,),
                                ),
                              ),
                            ),
                          ],
                        ),
                        Text("\$4.99",style: TextStyle(fontSize: normalFont,fontWeight: FontWeight.w600,color: Colors.black),)
                      ],
                    )
                  ],
                ),
              );
            }),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 20.0,right: 20.0),
            child: AppButton(
              bgColor: AppColors.bgGreen,
                name: "Go to Checkout",
                onClick: (){
                showModalBottomSheet(context: context, builder:(BuildContext context){
                  return Container(
                    padding: EdgeInsets.all(10),
                    height: 600,
                    width: double.infinity,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ListTile(
                          title: Text("Check Out",
                          style: TextStyle(
                              fontSize: titleFont,
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                          ),
                        ),
                          trailing: InkWell(
                            onTap: ()=>Navigator.pop(context),
                              child: Icon(Icons.close,color: Colors.black,)),
                        ),
                        Divider(),
                        ListbottomSheet(
                          title: "Delivery",
                          subtitle: Text("Select Method",),
                          onClick: (){},
                        ),
                        Divider(),
                        ListbottomSheet(
                          title: "Pament",
                          subtitle: Icon(Icons.credit_card,color: Colors.orange,),
                          onClick: (){},
                        ),
                        Divider(),
                        ListbottomSheet(
                          title: "Promo Code",
                          subtitle: Text("Pick discount",),
                          onClick: (){},
                        ),
                        Divider(),
                        ListbottomSheet(
                          title: "Total Cost",
                          subtitle: Text("\$13.97",),
                          onClick: (){},
                        ),
                        Divider(),
                        SizedBox(height: 10,),
                        SizedBox(
                          width:200,
                          child: RichText(text: TextSpan(
                            text: "By placing an order you agree to our  ",
                            style: TextStyle(fontSize:smallFont,color: AppColors.textGrey),
                            children: [
                              TextSpan(
                                text: " Terms ",
                                style: TextStyle(
                                    fontSize: smallFont,
                                    fontWeight: FontWeight.w500,
                                    color: Colors.black,
                                ),
                              ),
                              TextSpan(
                                text: " And ",
                                style: TextStyle(
                                    fontSize: smallFont,
                                    fontWeight: FontWeight.w400,
                                    color: AppColors.textGrey,
                                ),
                              ),
                              TextSpan(
                                text: " Conditions",
                                style: TextStyle(
                                    fontSize: smallFont,
                                    fontWeight: FontWeight.w500,
                                    color:Colors.black,
                                ),
                              ),
                            ]
                          )),
                        ),
                        SizedBox(height: 15,),
                        Center(
                          child: SizedBox(
                            width:300,
                              child: AppButton(name: "Place Order", onClick: (){})),
                        )
                      ],
                    ),
                  );
                });
                }
            ),
          ),
          SizedBox(height: 10,),
        ],
      )
    ));
  }
}


