package com.example.nectar

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
