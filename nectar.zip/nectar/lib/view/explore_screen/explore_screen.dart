import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:nectar/utility/app_color.dart';
import 'package:nectar/utility/fontsize.dart';
import 'package:nectar/view/explore_screen/widget/category_card.dart';
import 'package:nectar/view/shop_screen/widget/item_card.dart';
import 'package:nectar/widget/app_input.dart';

class ExploreScreen extends StatefulWidget {
  const ExploreScreen({super.key});

  @override
  State<ExploreScreen> createState() => _ExploreScreenState();
}

class _ExploreScreenState extends State<ExploreScreen> {
  final _searchController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      backgroundColor: AppColors.bgWhite,
      body: Padding(
        padding: const EdgeInsets.all(15.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Text("Find Products",
                style: TextStyle(
                    fontSize: titleFont,
                    fontWeight: FontWeight.w600,
                    color: Colors.black,
                ),
              ),
            ),
            SizedBox(height: 10,),
            AppInput(
              prefixIcon: Icon(Icons.search,color: Colors.black,),
                controller: _searchController,
                hintText: "Search Store",
            ),
            SizedBox(height: 20,),
            Expanded(
              child: GridView.builder(
                itemCount: 10,
                  gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                  mainAxisSpacing: 10,
                  crossAxisSpacing: 10,
                  ),
                  itemBuilder: (context,index){
                    return CategoryCard();
                  },
                  ),
            ),
          ],
        ),
      ),
    ));
  }
}
