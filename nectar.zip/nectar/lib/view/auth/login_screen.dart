import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:nectar/utility/assets.dart';
import 'package:nectar/view/auth/signup_screen.dart';
import 'package:nectar/view/auth/widget/app_field.dart';
import 'package:nectar/view/navigation_screen/navigation_screen.dart';
import 'package:nectar/widget/app_button.dart';
import 'package:nectar/widget/app_input.dart';

import '../../utility/app_color.dart';
import '../../utility/fontsize.dart';
import 'forgot_password.dart';

class LogInScreen extends StatefulWidget {
  const LogInScreen({super.key});

  @override
  State<LogInScreen> createState() => _LogInScreenState();
}

class _LogInScreenState extends State<LogInScreen> {

  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(

      backgroundColor:Colors.white,

      body: SingleChildScrollView(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Image.asset(
              Assets.gajorIcon,
              height: 60,
              width: double.infinity,
              fit: BoxFit.contain,
            ),
            SizedBox(height: 60,),
            Text("LogIn",
              style: TextStyle(
                fontWeight: FontWeight.w900,
                fontSize: bigFont,
                color: Colors.black,
              ),
            ),
            SizedBox(height: 5,),
            Text("Enter your emails and password",
              style: TextStyle(
                fontWeight: FontWeight.w400,
                fontSize: smallFont,
                color: Colors.grey,
              ),
            ),
            SizedBox(height: 30,),
            Text("Email",
              style: TextStyle(fontSize: normalFont,fontWeight: FontWeight.w600,color: AppColors.textGrey),),
            AppField(controller: _emailController, hintText: "Email"),
            SizedBox(height: 20,),
            Text("Password",
              style: TextStyle(fontSize: normalFont,
                  fontWeight: FontWeight.w600,
                  color: AppColors.textGrey,
              ),),
            AppField(
                controller: _passwordController,
                hintText: "Password",
              suffixIcon: Icon(Icons.remove_red_eye,color: AppColors.textGrey,),
            ),
            SizedBox(height: 15,),
            Align(
              alignment: Alignment.centerRight,
                child: InkWell(
                  onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>ForgotPassword())),
                  child: Text("Forgot Password?",
                    style: TextStyle(fontSize: normalFont,
                        fontWeight: FontWeight.w600,
                        color:Colors.black),
                  ),
                ),
            ),
            SizedBox(height: 40,),
            AppButton(
              bgColor: AppColors.bgGreen,
                name: "Log In", onClick: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>NavigationScreen())),

            ),
            SizedBox(height: 20,),
            Center(
              child: InkWell(
                onTap: ()=>Navigator.push(context, MaterialPageRoute(builder: (_)=>SignUpScreen())),
                child: RichText(text: TextSpan(
                  text: "Don’t have an account? ",
                  style: TextStyle(fontSize: normalFont,fontWeight: FontWeight.w500,color: Colors.black),
                  children: [
                    TextSpan(
                      text: "Sign Up",
                      style: TextStyle(fontWeight: FontWeight.w500,fontSize: normalFont,color:AppColors.bgGreen)
                    )
                  ]
                )),
              ),
            )




          ],
        ),
      ),
    ),
    );
  }
}
