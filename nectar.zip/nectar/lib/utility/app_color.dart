
import 'dart:ui';

class AppColors{
  static const Color bgWhite = Color(0xFFFFFFFF);
  static const Color bgGreen = Color(0xFF53B175);
  static const Color textGrey = Color(0xFF7C7C7C);
  static const Color cardColor = Color(0xFFF8A44C);

}

