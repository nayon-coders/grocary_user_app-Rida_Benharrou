import 'package:flutter/material.dart';
import 'package:nectar/utility/fontsize.dart';
import 'package:nectar/view/auth/login_screen.dart';

import '../../utility/app_color.dart';

class AccountScreen extends StatefulWidget {
  const AccountScreen({super.key});

  @override
  State<AccountScreen> createState() => _AccountScreenState();
}

class _AccountScreenState extends State<AccountScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      body: SingleChildScrollView(
        padding: EdgeInsets.all(10),
        child: Column(
          children: [
            ListTile(
              leading: Icon(Icons.account_circle_outlined,color: Colors.black,size: 40,),
              title: Text("Shakib KB",style: TextStyle(fontSize: titleFont,color: Colors.black),),
              subtitle: Text("shakib.app.dev@gmail.com",style: TextStyle(fontSize: smallFont,color: AppColors.textGrey),),
            ),
            SizedBox(height: 20,),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.shop,color: Colors.black,),
              title: Text("Orders"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.account_balance_wallet_sharp,color: Colors.black,),
              title: Text("My Details"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.location_on,color: Colors.black,),
              title: Text("Delivery Address"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.wallet,color: Colors.black,),
              title: Text("Payment Methods"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.credit_card_sharp,color: Colors.black,),
              title: Text("Promo Cord"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.notifications_none,color: Colors.black,),
              title: Text("Notifecations"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
                onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.question_mark,color: Colors.black,),
              title: Text("Help"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){},
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.error_outline,color: Colors.black,),
              title: Text("About"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
            ListTile(
              onTap: (){
                Navigator.push(context, MaterialPageRoute(builder: (_)=>LogInScreen()));
              },
              shape: Border.symmetric(horizontal: BorderSide(color: Colors.black12)),
              contentPadding: EdgeInsets.all(10),
              leading: Icon(Icons.logout,color: Colors.black,),
              title: Text("Log Out"),
              trailing: Icon(Icons.keyboard_arrow_right),
            ),
          ],
        ),
      ),
    ));
  }
}
