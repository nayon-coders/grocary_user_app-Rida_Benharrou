

double smallFont = 12.0;
double normalFont = 16.0;
double titleFont = 18.0;
double bigFont = 22.0;
