import 'package:flutter/material.dart';
import 'package:nectar/utility/app_color.dart';
import 'package:nectar/utility/fontsize.dart';
import 'package:nectar/view/shop_screen/widget/item_card.dart';

class BeveragesScreen extends StatefulWidget {
  const BeveragesScreen({super.key});

  @override
  State<BeveragesScreen> createState() => _BeveragesScreenState();
}

class _BeveragesScreenState extends State<BeveragesScreen> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: AppColors.bgWhite,
        leading: InkWell(
          onTap: ()=>Navigator.pop(context),
            child: Icon(Icons.arrow_back_ios,color: Colors.black,)),
        title: Text("Beverages",
          style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: titleFont,
              color: Colors.black),
        ),
        centerTitle: true,
        actions: [
          Icon(Icons.filter_list,color: Colors.black,),
          SizedBox(width: 10,),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: GridView.builder(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              mainAxisSpacing: 6,
                crossAxisSpacing: 6,
                crossAxisCount: 2
            ),
            itemBuilder: (context,index){
              return ItemCard();
            }),
      ),
    ));
  }
}
